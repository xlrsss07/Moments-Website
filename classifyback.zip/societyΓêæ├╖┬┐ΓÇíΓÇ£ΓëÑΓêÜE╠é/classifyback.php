<?php
	require_once 'header.php';
	 if(isset($_GET['society']))
	 {
	 	$society=execMysql("SELECT * FROM association WHERE class=?",array($_GET['society']),TRUE);

	 	if($society->rowCount()===0)
        {
            //die404();//TODO:如果这个类里面没有一个社团的话，应该显示这个，假定没有社团不为0的情况
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"Cannot find such event"
            ))) ;
        }
		//这里是读取对应这个类里面的社团名字
        $title=Array();
        foreach($society as $row)
        {
        	$title[] = $row['association_name'];
        }


		//读取社团对应的图片
        $img=array();
        foreach($society as $row){
        	$filepath="./upload/society/society_{$row['association_ID']}/1.jpg";
        	$img[]=$filepath;
        }

		echo $json=json_encode(array(
            "resultCode"=>200,
            "name"=>$society['association_name'],
            "img"=>$img,
        ));

	 }
?>