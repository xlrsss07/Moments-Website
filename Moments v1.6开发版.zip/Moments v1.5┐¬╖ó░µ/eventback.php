<?php

    require_once 'header.php';

    if(isset($_GET['id']))
    {
        $event=execMysql("SELECT * FROM event WHERE event_ID=?",array($_GET['id']),TRUE);

        if($event->rowCount()===0)
        {
            //die404();//TODO:如果社团搜索不到应该显示这个
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"Cannot find such event"
            ))) ;
        }

        $eventunit=$event->fetch();

        $temp=explode(' ',$eventunit['event_date']);
        //var_dump($temp);
        list($year,$month,$day)=explode("-",$temp[0]);
        list($hour,$minute,$second)=explode(":",$temp[1]);
        $d=mktime($hour, $minute, $second, $month, $day, $year);
        //echo date("l jS F Y", $d),"<br>";

        $img=array();
        for($i=1;$i<=$eventunit['pictureNum'];$i++)
        {
            $filepath="./upload/society/society_{$eventunit['asso_ID']}/event_{$_GET['id']}/{$i}.jpg";
            $img[]=$filepath;
        }

        //TODO:中间的那个Events You Might Like由于缺少算法就不管
        //TODO：用户针对某个用户的回复占时还有LIKE先不管，结合的时候那段代码直接删了或者不管他

        $comment_user=execMysql("SELECT * FROM comment WHERE comment_event_ID=?",array($_GET['id']),TRUE);


        $comment=Array();
        //这里不检测数量了，数量为0的话为空数组
        foreach($comment_user as $row)
        {
            $userunit=Array();;
            //echo "Displayname: ",$row['comment_display_name'],"<br>"; //TODO：网名
            $userunit['displayname']=$row['comment_display_name'];

            $temp=explode(' ',$row['comment_date']);
            //var_dump($temp);
            list($year,$month,$day)=explode("-",$temp[0]);
            list($hour,$minute,$second)=explode(":",$temp[1]);

            //echo $year," ",$month," ",$day," ",$hour," ",$minute," ",$second,"<br>";

            $d=mktime($hour, $minute, $second, $month, $day, $year);
            //echo "Date: ",date("m-d G:i", $d),"<br>";    //TODO:发表评论的时间

            //TODO:时间不会显示年份，先不管他了
            $userunit['date']=date("m-d G:i", $d);

            //echo "Content: ",$row['comment_content'],"<br>"; //TODO:发表评论的内容
            $userunit['content']=$row['comment_content'];

            //TODO：目前用户上传文件只有这两种格式，到时候再加，当然home那里还没加，到了适合时间在做统一处理

            $header="./upload/users/user_id{$row['comment_user_ID']}/header.jpg";
            //echo $header,"<br>";
            $userunit['header']=$header;

            $comment[]=$userunit;
        }




        echo $json=json_encode(array(
            "resultCode"=>200,
            "name"=>$eventunit['event_name'],
            "date"=>date("Y-m-d\TG:i:s", $d),
            "location"=>$eventunit['event_location'],
            "limitation"=>$eventunit['limitation'],
            "description"=>$eventunit['event_description'],
            "img"=>$img,
            "comment"=>$comment
        ));

        file_put_contents('test.json', $json);

        //echo "<br>123";
        /*echo "event name: ",$eventunit['event_name'],"<br>"; //TODO:活动名字

        //2019-05-01T14:00:00
        $temp=explode(' ',$eventunit['event_date']);
        //var_dump($temp);
        list($year,$month,$day)=explode("-",$temp[0]);
        list($hour,$minute,$second)=explode(":",$temp[1]);
        $d=mktime($hour, $minute, $second, $month, $day, $year);
        //echo date("l jS F Y", $d),"<br>";
        echo date("Y-m-d\TG:i:s", $d),"<br>"; //TODO:对应页面Time的值

        echo "Location: ",$eventunit['event_location'],"<br>"; //TODO:活动地点

        echo "Description: ",$eventunit['event_description	'],"<br>";  //TODO:活动描述

//TODO:这个出来的是一个数字，123对应三个选项，跟上面那种简单赋值不一样，如果你知道怎么做，那就自己弄，不知道跟我说下我来弄
        echo "Limitation: ",$eventunit['limitation'],"<br>";
         */
    }
    elseif (isset($_POST['id']))
    {
        if(!isset($_SESSION['ID']))
        {
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"Please log in at first"
            ))) ;
        }
        $permission=execMysql("SELECT user_level FROM association_touser 
                            WHERE chatroom_ID=? AND user_ID=?",
                            array($_POST['id'],$_SESSION['ID']),true);
        if($permission->rowCount()===0 || $permission->fetch()['user_level']<2)
        {
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"You do not have permission"
            ))) ;
        }


        $result=execMysql("SELECT event_ID FROM event WHERE event_ID=?",array($_POST['id']),true);
        if($result->rowCount()===0)
        {
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"Cannot find such error"
            ))) ;
        }

        if(isset($_POST['event_name'])&&isset($_POST['time'])&&
            isset($_POST['location'])&&isset($_POST['description'])&&
            isset($_POST['limitation']))
        {
            //TODO:这个地方到时候写根据session来判断修改的人是否有权限

            //TODO:如果考虑安全性还需要加一个过滤
            //sanitizeString()

            if(!preg_match("/^[123]$/",$_POST['limitation']) ||
                !preg_match("/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/",$_POST['time']))
            {

                //如果limitation或者time传过来的不合法，至于什么错误并不需要告诉他们
                die(json_encode(array(
                    "resultCode"=>404,
                    "message"=>"Update failed,please try again"
                )));
            }
            $connection->beginTransaction();
            $stmt= $connection->prepare("UPDATE event SET event_name=?,
                                event_date=?,event_location=?,
                                event_description=?,limitation=? 
                                WHERE event_ID=?");
            $success=$stmt->execute(array($_POST['event_name'],
                    $_POST['time'],$_POST['location'],
                    $_POST['description'],$_POST['limitation'],
                    $_POST['id']));
            //TODO:图片修改暂时不管，因为前端那里出现问题
            if($success===true)
            {
                $connection->commit();

                die(json_encode(array(
                    "resultCode"=>200,
                    "message"=>"Update successful"
                )));

            }
            else
            {
                $connection->rollBack();

                die(json_encode(array(
                    "resultCode"=>404,
                    "message"=>"Update failed,please try again"
                )));
            }
        }
        else
        {
            //缺少必要项目，至于什么错误并不需要告诉他们
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"Update failed,please try again"
            )));
        }
    }
    /*
    if(!isset($_GET['id']))
    {
        if (!isset($_POST['id']))
        {
            //die404();
            die(json_encode(array(
                "resultCode"=>404,  //TODO:这里可以考虑重定向到之前页面
                "message"=>"Cannot find such error"
            )));
        }

        //TODO:如果是修改的话，理论上网页除了POST相关数据，还会POST其ID

    }
    else
    {
        //TODO:少一个会话来检测身份，到时候心情稍微好一点了再写


    }
*/






