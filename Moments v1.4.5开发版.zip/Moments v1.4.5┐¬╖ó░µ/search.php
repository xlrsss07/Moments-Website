<?php
    require_once 'functions.php';

    //跟home原理，如果没有输入text参数，就暂时变成404 not found，到了后期再换成302重定向到其他页面上去
    //TODO:注意php代码中什么echo <br><pre>什么的去掉，那是调试时整理格式用的东西
    require_once 'functions.php';

    if(!isset($_GET['text']))
    {
        die404();
        return;
    }
    $resultNum=0; //TODO:用于显示查找结果次数，根据前端说法应该是放在一个js的构造器的参数中

    $searchText='%'.$_GET['text'].'%';
    $resultAsso=execMysql("SELECT * FROM association WHERE association_name LIKE ?",array($searchText),TRUE);
    if($resultAsso->rowCount()===0)
    {
        echo "No result";//TODO:如果社团搜索不到应该显示这个
    }

    foreach ($resultAsso as $row)
    {
        echo $row['association_name'],"<br>";
        $filepath="./upload/society/{$row['association_name']}/header.jpg"; //TODO:社团对应的头像
        echo $filepath,"<br>";

        $linkSociety="./society.php?id={$row['association_ID']}";   //TODO:社团对应的链接
        echo $linkSociety,"<br>";
    }
    echo "<br>";


    //TODO:可能这种查询效率不高，到时候慢了再改
    $resultEvent=execMysql("SELECT * FROM association a,event e 
                    WHERE a.association_ID=e.asso_ID AND event_name LIKE ?",array($searchText),TRUE);
    if($resultEvent->rowCount()===0)
    {
        echo "No result";  //TODO:如果活动搜索不到应该显示这个
    }
    foreach ($resultEvent as $row)
    {
        //echo $row['association_name'],"\n";
        $filepath="./upload/society/{$row['association_name']}/event/{$row['event_name']}/header.jpg"; //TODO:活动对应的头像
        echo $filepath,"<br>";

        $linkEvent="./event.php?id={$row['event_ID']}"; //TODO:活动对应的链接
        echo $linkEvent,"<br>";
    }


    echo "</pre>";
?>
