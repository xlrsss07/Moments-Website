<?php
    require_once "header.php";

    if(isset($_GET['id']))
    {
        $moments_result=execMysql("SELECT * FROM moments WHERE moments_senderID=?",
            array($_GET['id']),true);
        $user_result=execMysql("SELECT user_login FROM users WHERE ID=?",
                        array($_GET['id']),true);

        $user=$user_result->fetch();

        $moments=array();
        foreach($moments_result as $row)
        {
            $moments_unit=array();

            $moments_unit['content']=$row['moments_description'];
            $moments_unit['img']=array();
            if($row['moments_pictureNum']===0)
            {
                //默认图片路径
                $moments_unit['img'][0]="./images/logo.png";
            }
            else
            {
                for($i=1;$i<=$row['moments_pictureNum'];$i++)
                {
                    $moments_unit['img'][]="./upload/users/user_id{$_GET['id']}
                                    /moments/moments_id{$row['moments_ID']}/{$i}.jpg";
                }
            }
            $moments[]=$moments_unit;

        }

        echo $json=json_encode(array(
            "resultCode"=>200,
            "displayname"=>$user['user_login'],
            "header"=>"./upload/users/user_id{$_GET['id']}/header.jpg",
            "moments"=>$moments
        ));
    }