﻿<?php

    require_once 'functions.php';
    if(isset($_GET['id']))
    {
        $association=execMysql("SELECT * FROM association WHERE association_ID=?",array($_GET['id']),TRUE);
        if($association->rowCount()===0)
        {
            die(json_encode(array(
                "resultCode"=>404,
                "message"=>"Cannot find such society"
            ))) ;
            //
        }
        $asso_unit=$association->fetch();

        //图片地址
        $poster_img=Array();
        for($i=1;$i<=$asso_unit['pictureNum'];$i++)
        {
            $filepath="./upload/society/society_{$_GET['id']}/{$i}.jpg";
            $poster_img[]=$filepath;
        }

        $message_result=execMysql("SELECT *,UNIX_TIMESTAMP(msg_date) as timestamp 
                    FROM groupmsg WHERE chatroom_ID=? ORDER BY msg_date",
                    array($_GET['id']),TRUE);
        //这里不检测数量了，数量为0的话为空数组
        $messages=Array();
        foreach ($message_result as $row)
        {
            $message_unit=Array();
            $message_unit['displayname']=$row['msg_sendername'];

            //发表时间,现在变成了7个小时，到时候到了冬令时要改成8
            $timediff=time()-$row['timestamp']-7*3600;
            if($timediff>60*60*24)
            {
                $timeago=floor($timediff/86400);
                //echo "$timeago days ago";
                $timeans="$timeago days ago";
            }
            elseif ($timediff>60*60)
            {
                $timeago=floor($timediff/3600);
                //echo "$timeago hours ago";
                $timeans="$timeago hours ago";
            }
            else
            {
                $timeago=floor($timediff/60);
                //echo "$timeago minutes ago";
                $timeans="$timeago minutes ago";
            }

            $message_unit['time']=$timeans;
            $message_unit['content']=$row['msg_content'];

            $messages[]=$message_unit;
        }

        $user_result=execMysql("SELECT * FROM association_touser WHERE chatroom_ID=?",
                    array($_GET['id']),TRUE);
        $usergroup=Array();
        //同理不检测数量，数量为0的话为空数组
        foreach($user_result as $row)
        {
            $user_unit=Array();
            $user_unit['display_name']=$row['user_displayname'];
            $user_unit['level']=$row['user_level'];

            $usergroup[]=$user_unit;


        }

        //TODO:找最新的5条，因为随机貌似有点问题？
        $moments_result=execMysql("SELECT * FROM moments 
                                WHERE moments_assoID=? 
                                ORDER BY moments_ID DESC LIMIT 5",array($_GET['id']),true);
        $moments=Array();
        foreach ($moments_result as $row)
        {
            $moment_unit=Array();
            $moment_unit['title']=$row['moments_title'];

            $temp=execMysql("SELECT user_login FROM users WHERE ID=? limit 1",array($row['moments_senderID']),true);
            $temp=$temp->fetch();
            $moment_unit['display_name']=$temp['user_login'];

            $moment_unit['pictNum']=$row['moments_pictureNum'];
            $moment_unit['pictHeader']="./upload/users/user_id{$row['moments_senderID']}".
                                        "/moments/moments_id{$row['moments_ID']}/header.jpg";

            //TODO:moments的超链接，等moments写好了再加
            $moment_unit['href']="";

            $moments[]=$moment_unit;
        }

        $event_result=execMysql("SELECT * FROM event
                                WHERE asso_ID=? ORDER BY asso_ID DESC LIMIT 5",
                                array($_GET['id']),true);

        $events=Array();
        foreach ($event_result as $row)
        {
            $event_unit=Array();
            $event_unit['title']=$row['event_name'];
            $event_unit['number']=$row['pictureNum'];

            $event_unit['pictHeader']="./upload/society_{$row['asso_ID']}/event_{$row['event_ID']}/header.jpg";
            $event_unit['href']="./event.php?id={$row['event_ID']}";

            $events[]=$event_unit;
        }

        //TODO:随机查找5个，但是网上说这种办法效率很低
        $member_result=execMysql("SELECT ID,user_login FROM usermeta,users
                                WHERE users.ID=usermeta.user_ID 
                                AND meta_key='subscribe_association' 
                                AND meta_value=? ORDER BY RAND() LIMIT 5",
                                array($_GET['id']),true);

        $members=Array();
        foreach($member_result as $row)
        {
            //TODO: 等级先不考虑了,不是说好了没有关注度了吗？
            $member_unit=Array();
            $member_unit['name']=$row['user_login'];
            $member_unit['header']="./upload/users/user_id{$row['ID']}/header.jpg";
            //TODO:member的超链接，等user写好了再加
            $member_unit['href']="";

            $members[]=$member_unit;
        }

        echo $json=json_encode(array(
            "resultCode"=>200,
            "poster_img"=>$poster_img,
            "description"=>$asso_unit['association_description'],
            "contact"=>$asso_unit['association_contact'],
            "address"=>$asso_unit['association_address'],
            "chat_message"=>$messages,
            "chat_users"=>$usergroup,
            "moments"=>$moments,
            "events"=>$events,
            "members"=>$members
        ));

        //file_put_contents('test.json', $json);
    }
    //TODO:用于修改社团，先放在这里
    elseif(isset($_POST['id']))
    {
        echo "";
    }
